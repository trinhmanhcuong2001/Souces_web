<?php
include "includes/config.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>School</title>
<style type="text/css">

<!--
a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #D58309;
}
a:active {
	text-decoration: none;
}
.style17 {
	color: #FFFFFF;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
.style18 {
	color: #666666;
	font-weight: bold;
}
.text{
vertical-align:top;
}
.style19 {font-family: Arial, Helvetica, sans-serif}
.style20 {color: #666666; font-weight: bold; font-family: Arial, Helvetica, sans-serif; }
.style20 strong {
	color: #0080C0;
	font-size: xx-large;
}
.Heading {
	text-transform: uppercase;
	color: #006FA4;
	font-weight: bold;
	font-size: x-large;
	font-style: normal;
	line-height: normal;
	font-variant: normal;
	text-decoration: none;
}
-->
</style>

<link rel="stylesheet" type="text/css" href="sdmenu/sdmenu.css" />
	<script type="text/javascript" src="sdmenu/sdmenu.css">
		/***********************************************
		* Slashdot Menu script- By DimX
		* Submitted to Dynamic Drive DHTML code library: http://www.dynamicdrive.com
		* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
		***********************************************/
	</script>
	<script type="text/javascript">
	// <![CDATA[
	var myMenu;
	window.onload = function() {
		myMenu = new SDMenu("my_menu");
		myMenu.init();
	};
	// ]]>
	</script>
</head>

<body topmargin="0" leftmargin="0" rightmargin="0" bottommargin="0"  marginheight="0" marginwidth="0">
<form name="loginform" action="sub_login.php" method="post" onsubmit="return loginval();">

<table bgcolor="#000000" width="100%" height="100%"  border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr>
    <td width="1%" height="577">&nbsp;</td>
    <td width="775" valign="top"><table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" align="center">
      <tr>
        <td height="65" valign="bottom" bgcolor="#B6E9FA"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#00B6DE">
          <tr></tr>
        </table>
          <table width="100%" height="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF" align="center">
            <!--DWLayoutTable-->
            <tr align="center" bgcolor="#B6E9FA">
              <td width="926" rowspan="2" valign="middle" class="Heading">Great Britain Play School</td>
            <td width="34" height="20">&nbsp;</td>
            </tr>
            <tr align="center" bgcolor="#B6E9FA">
              <td height="30" valign="bottom"><a href="../index.php" onclick="window.close()"><img src="images/home.jpg" width="21" border="0" alt="Home" title="Home" /></a></td>
            </tr>
            <tr>
              <td height="460" colspan="2" valign="top"><table width="100%" border="0" cellpadding="0" cellspacing="0" align="center">
              <!--DWLayoutTable-->
              <tr>
                <td width="202" height="25">&nbsp;</td>
                
                <td width="569" align="right" valign="top">&nbsp;</td>
                <br />

                <div style="float: left" id="my_menu" class="sdmenu">
     
      <div>
        <span>Import Student</span>
        <!--<a href="cg/search_student.php?mode=search">Search Student List</a> 
		<a href="cg/birthdate.php?mode=search">Birthdate Calendar</a> -->
		<a href="greatbritain/import_stud.php">Import Student</a> 
		<a href="greatbritain/import_staff.php">Import Staff</a>
		<!--<a href="sunrise/import_staff.php">Import Staff</a> -->
		      </div>
     
		
    </div>
	

  <div style="padding-left: 200px">
    <pre>&nbsp;</pre>
    </div>
			  </tr>
              <tr>
                <td height="401"></td>
                <td>&nbsp;</td>
              </tr>
              
            
          </table></td>
            </tr>
            <tr>
              <td height="27"></td>
              <td></td>
            </tr>
            <tr>
              <td height="65" colspan="2" valign="bottom" bgcolor="#B6E9FA"><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#00B6DE">
                <!--DWLayoutTable-->
                <tr>
                  <td width="745" height="49" valign="middle" bgcolor="#279AEB"><div align="center" class="style17">All Rights Reserved to  Hubcity Softwares Pvt. Ltd. </div></td>
                </tr>
              </table></td>
            </tr>
          </table>
          <table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#00B6DE">
          </table></td>
      </tr>
    </table></td>
    <td width="1%">&nbsp;</td>
  </tr>
</table>
</form>
</body>
</html>
