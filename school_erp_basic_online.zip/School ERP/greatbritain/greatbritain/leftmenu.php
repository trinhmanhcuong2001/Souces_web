<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Untitled Document</title>
<link rel="stylesheet" type="text/css" href="../sdmenu/sdmenu.css" />
	<script type="text/javascript" src="../sdmenu/sdmenu.js">
		/***********************************************
		* Slashdot Menu script- By DimX
		* Submitted to Dynamic Drive DHTML code library: http://www.dynamicdrive.com
		* Visit Dynamic Drive at http://www.dynamicdrive.com/ for full source code
		***********************************************/
	</script>
	<script type="text/javascript">
	// <![CDATA[
	var myMenu;
	window.onload = function() {
		myMenu = new SDMenu("my_menu");
		myMenu.init();
	};
	// ]]>
	</script>
</head>

<body>

     <div style="float: left" id="my_menu" class="sdmenu">
      
      <div>
        <span>Import Student</span>
       
		
		<a href="import_stud.php">Import Staff</a> 
		<!--<a href="import_staff.php">Import Staff</a> -->
		
         </div>
      
    
    </div>
	

  <div style="padding-left: 200px">
    <pre>&nbsp;</pre>
    </div>
</body>
</html>
