<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>School</title>
<style type="text/css">


a:link {
	text-decoration: none;
}
a:visited {
	text-decoration: none;
}
a:hover {
	text-decoration: none;
	color: #D58309;
}
a:active {
	text-decoration: none;
}
.style17 {
	color: #FFFFFF;
	font-size: 12px;
	font-family: Arial, Helvetica, sans-serif;
}
.style18 {
	color: #666666;
	font-weight: bold;
}
.text{
vertical-align:top;
}
.style19 {font-family: Arial, Helvetica, sans-serif}
.style20 {color: #666666; font-weight: bold; font-family: Arial, Helvetica, sans-serif; }
.style20 strong {
	color: #0080C0;
	font-size: xx-large;
}
.Heading {
	text-transform: uppercase;
	color: #006FA4;
	font-weight: bold;
	font-size: x-large;
	font-style: normal;
	line-height: normal;
	font-variant: normal;
	text-decoration: none;
}

</style>
</head>

<body>


<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <!--DWLayoutTable-->
  <tr align="center" bgcolor="#B6E9FA">
              <td width="941" rowspan="2" valign="middle" class="Heading">Great Britain Play School</td>
			  <td width="32" height="18"></td>
              <td width="2"></td>
  </tr>
  <tr align="center" bgcolor="#B6E9FA">
    <td height="32" valign="bottom"><a href="../../index.php"><img src="../images/home.jpg" width="21" border="0" /></a></td>
  <td></td>
  </tr>
</table>
</body>
</html>
