<?
$connection=mysql_connect("localhost","root","");
$db=mysql_select_db("erp2",$connection);
?>