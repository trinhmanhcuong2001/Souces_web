<table width="100" border="0" cellspacing="1" cellpadding="0">
                      <tr>                       
                        
                       
                        <td width="16%" align="center" valign="bottom">
                            <table width="100%" height="27" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td width="8%" align="left" valign="bottom" class="btn1">&nbsp;</td>
                                  <td width="84%" align="center" valign="middle" class="btn2"><a href="#" class="btn">Back to Site</a></td>
                                  <td width="8%" align="left" valign="bottom" class="btn3">&nbsp;</td>
                                </tr>
                            </table>
                        </td>
                       <!-- <td width="18%" align="center" valign="bottom">
                            <table width="100%" height="27" border="0" cellpadding="0" cellspacing="0">
                                <tr>
                                  <td width="8%" align="left" valign="bottom" class="btn1">&nbsp;</td>
                                  <td width="84%" align="center" valign="middle" class="btn2"><a href="exam/index.php" class="btn">Online Exam</a></td>
                                  <td width="8%" align="left" valign="bottom" class="btn3">&nbsp;</td>
                                </tr>
                            </table>
                        </td>-->
                        
                      </tr>
                    </table>