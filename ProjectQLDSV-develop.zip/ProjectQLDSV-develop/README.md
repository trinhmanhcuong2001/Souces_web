<img src="https://github.com/ProjectGKHTPT/ProjectQLDSV/blob/master/image/00.png" /><br/>
<center><H2>GIỚI THIỆU DỰ ÁN WEBSITE QUẢN LÝ ĐIỂM SINH VIÊN</H2></center>
<hr/></br>
<p>Tài liệu này được xây dựng bởi các thành viên:</br>
                      -Nguyễn Trọng Lâm</br>
                      -Bùi Nguyễn Hồng Phúc</br>
 	                    -Nguyễn Thị Mỹ Linh</p></br>
                      
<p><H4>Tóm tắt</H4><br/>
<li> GIỚI THIỆU  </li>
<li> MỤC TIÊU</li>
<li> KẾ HOẠCH</li>
<li> CÔNG CỤ HỖ TRỢ</li>
<li> KẾT LUẬN</li>
  
</p><br/>

<p><H4>1.GIỚI THIỆU</H4><br/>
-Mô tả chức năng của trang web<br/>
<img src="https://github.com/ProjectGKHTPT/ProjectQLDSV/blob/master/image/01.png" /><br/>
  
<p><H4>2.MỤC TIÊU</H4><br/>
  - Trang Web thực hiện đầy đủ chức năng yêu cầu của Project môn học " Hệ Thống Phân Tán ".<br/>
  - Áp dụng WebService Hệ Thống Phân Tán. <br/>
  - Sử dụng Flyway để quản lý CSDL web. <br/>
  - Sử dụng Testcase để test các chức năng của trang web. <br/>
  - Nâng cao các kỹ năng làm việc nhóm.<br/>

<p><H4>3. KẾ HOẠCH</H4><br/>
  
<p><H4>4. CÔNG CỤ HỖ TRỢ</H4></br>  
  -Framework laravel</br> 
  -Bootstrap</br> 
  -Flyway</br> 
  -github</br> 
  -xampp</br> 
  ....
<p><H4>5. KẾT LUẬN</H4></br> 
  - Biết sử dụng kiến thức " Hệ Thống Phân Tán " vào thiết kế web.</br> 
  - Thành thạo kĩ năng làm việc nhóm cũng như project nhóm.</br> 
  - Biết sử dụng một số Framwork cũng như các tính năng quản lý CSDL của Flyway.</br> 
  - Kiến thức sử dụng TestCase.</br> 
