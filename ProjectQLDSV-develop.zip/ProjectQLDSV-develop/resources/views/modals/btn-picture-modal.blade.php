<div class="btn-group picture_btn relative" style="position: relative">
    <button class="btn btn-block btn-xs btn-flat dropdown-toggle" type="button" data-toggle="dropdown">
        <i class="fa fa-picture-o" aria-hidden="true"></i> &nbsp;&nbsp;&nbsp;&nbsp;<i class="fa fa-angle-right" aria-hidden="true"></i>
    </button>
    <ul class="dropdown-menu animated fadeInRight" role="menu">
        <img src="{{asset('image/'.@$picture)}}" width="100%">
    </ul>
</div>
