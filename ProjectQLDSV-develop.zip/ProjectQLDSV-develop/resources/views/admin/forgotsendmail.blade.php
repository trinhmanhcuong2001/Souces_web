<p>Xin chào</p>
<p>Đây là mã xác nhận của bạn:<b style="color: #14d1ff">{{$code}}</b></p>