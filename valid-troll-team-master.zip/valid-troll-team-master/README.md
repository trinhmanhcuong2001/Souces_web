## Test Online : https://minhtuan29.github.io/valid-troll-team  
 Xem demo tại : https://www.facebook.com/tamsudeveloper/videos/445315024334016  
 Đây là dự án đóng góp cho cộng đồng nhóm FE Việt Nam  
# Tác giả source code
## Hoàng Minh Tuấn
# Sharing
Nếu thấy hay thì bạn hãy ủng hộ kênh Youtube fullstack FE-BE-AI-MC-Game của mình để học tập giao lưu nhé ^  
## https://www.youtube.com/channel/UCEZ11BfdWpcOAbA86im7nFw 
