 <div class="sidebar">
 
                        <ul class="widget widget-menu unstyled">
                            <li class="active"><a href="http://localhost/project/"><i class="menu-icon icon-dashboard"></i>Trang chủ
                            </a></li>
                           
                        </ul>
                        <ul class="widget widget-menu unstyled">
                               
                             <li><a href="index.php?page=dstau"><i class="menu-icon icon-table"></i>Danh sách tàu</a></li>
                             <li><a href="index.php?page=dstoa"><i class="menu-icon icon-table"></i>Danh sách toa</a></li>
                             <li><a href="index.php?page=dsghe"><i class="menu-icon icon-table"></i>Danh sách ghế</a></li>
                             <li><a href="index.php?page=dslt"><i class="menu-icon icon-table"></i>Danh sách lịch trình</a></li>
                        </ul>
                      
                        <ul class="widget widget-menu unstyled">
                            <li><a href="index.php?page=dskh"><i class="menu-icon icon-group"></i>Khách Hàng </a>
                            </li>
                            <li><a href="index.php?page=dsnv"><i class="menu-icon icon-group"></i>Nhân Viên </a>
                            </li>
                            
                            <li><a href="index.php?page=logout"><i class="menu-icon icon-signout"></i>Thoát </a></li>
                        </ul>
                    </div>
