
  <header>
        <div class="navbar navbar-fixed-top">
            <div class="navbar-inner">
                <div class="container">
                    <a class="btn btn-navbar" data-toggle="collapse" data-target=".navbar-inverse-collapse">
                        <i class="icon-reorder shaded"></i></a><a class="brand" href="index.php">Administrator - Quản Lý Chức Năng </a>
                    <div class="nav-collapse collapse navbar-inverse-collapse">
                     
                        <ul class="nav pull-right">
                           
                            <li><a href="" style="font-size: 18px">Chào Admin</a></li>
                            <li><a href="index.php?page=logout">Thoát</a></li>
                        </ul>
                    </div>
                    <!-- /.nav-collapse -->
                </div>
            </div>
            <!-- /navbar-inner -->
        </div>
        <!-- /navbar -->
  </header>