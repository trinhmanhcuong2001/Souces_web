<?php
        $db=new PDO("mysql:host=localhost;dbname=quanlyvetau",
                "root","");
        $db->exec("set names utf8");
?>