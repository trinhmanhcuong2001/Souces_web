<body class="archive post-type-archive post-type-archive-route wpb-js-composer js-comp-ver-4.11.2.1 vc_responsive">
<div id="tt-wide-layout" >
<div id="tt-header-wrap" >

    <aside class="top-aside clearfix">
        <div class="center-wrap">
            <div class="one_half">
                <div class="sidebar-widget widget_text">            <div class="textwidget"><ul class="list">
<li style="font-weight: 700;
    font-size: 16px;">Tổng đài vé Online:<a href="tel:19001730" style="font-weight: 700;
    font-size: 16px;"> 1900 6469</a></li>
</ul>
</div>
        </div>            </div><!-- end .top-toolbar-left -->

            <div class="one_half">
                <div class="sidebar-widget widget_text">            <div class="textwidget"><div class="social-top">
<ul>
<li>
            <a href="https://www.facebook.com/DailyvexeHaNoiVinh"><i class="fa fa-facebook"></i><br />
        </a>
        </li>
<li>
            <a href="https://twitter.com"><i class="fa fa-twitter"></i><br />
        </a>
        </li>
<li>
            <a href="https://www.google.com.vn/"><i class="fa fa-google-plus"></i><br />
        </a>
        </li>
<li>
            <a href="https://www.youtube.com/channel/UCVGN2liHOox8Ob8sbb88qhQ?view_as=subscriber"><i class="fa fa-youtube"></i><br />
        </a>
        </li>
</ul>
</div>
</div>
        </div>            </div><!-- end .top-toolbar-right -->
        </div><!-- end .center-wrap -->
        <div class="top-aside-shadow"></div>
    </aside>

    <header >
        <div class="center-wrap">
            <div class="companyIdentity">
                                                            <a href="http://localhost/project/"><img src="wp-content/uploads/2018/05/dsvn1.png" alt="Tàu Bông Sen Vàng" /></a>
                                                </div><!-- end .companyIdentity -->
            <nav>
                <ul id="menu-main-nav">
                 
<li id="menu-item-672" class="menu-item menu-item-type-custom menu-item-object-custom current-menu-item menu-item-672"><a href="#">Lịch trình</a></li>


                </ul>
            </nav>
        </div><!-- end .center-wrap -->
    </header>
</div><!-- END #tt-header-wrap -->
    <section class="small_banner">
            <div class="center-wrap banner-no-crumbs">
                    <p class="page-banner-heading"></p>
        
                                        </div><!-- end .center-wrap -->
    <div class="shadow top"></div>
    <div class="shadow bottom"></div>
    <div class="tt-overlay"></div>
    </section>

<section id="content-container" class="clearfix">
    <div class="center-wrap tt-relative clearfix">
                <div class="section-list" id="Star-ha-noi">
            <h3 class="text-uppercase text-success">
                <span class="sprite ico-drive"></span>Hà Nội <i class="fa fa-exchange"> Miền Nam</i>
            </h3>    
            <div class="table-responsive">
                <table class="table ">
                    <thead>
                        <tr class="text-white bg-light-green">
                            <th>STT</th>
                            <th data-toggle="true">Ga đi</th>
                            <th>Ga đến</th>
                            <th data-hide="phone">Tên tàu</th>
                            <th data-hide="phone" style="text-align: center;">Ngày Đi</th>
                            <th data-hide="phone" style="text-align: center;">Ngày Về</th>
                            <th data-hide="phone" style="text-align: center;">Giờ Xuất Phát</th>
                            <th data-hide="phone" style="text-align: center;">Giá vé</th>
                            <th></th>
                        </tr>
                    </thead> 
                    <tbody>
                         <tr class="route-row532">
                            <td>1</td>
                            <td>Ga Hà Nội</td>
                            <td>Ga Vinh</td>
                            <td>Tàu A01</td>
                            <td style="text-align: center;">2019-06-02</td>
                            <td style="text-align: center;">2019-06-03</td>
                            <td style="text-align: center;">12:00 AM</td>
                            <td style="text-align: center;">
                                <p>
                                    <strong class="text-primary">
                                        475.000<sup>đ/vé</sup>
                                    </strong>
                                </p>
                            </td>
                            
                        </tr>
                            <tr class="route-row532">
                            <td>2</td>
                            <td>Ga Hà Nội</td>
                            <td>Ga Sài Gòn</td>
                            <td>Tàu A02</td>
                            <td style="text-align: center;">2019-05-29</td>
                            <td style="text-align: center;">2019-05-30</td>
                            <td style="text-align: center;">15:00 PM</td>
                            <td style="text-align: center;">
                                <p>
                                    <strong class="text-primary">
                                        1050.000<sup>đ/vé</sup>
                                    </strong>
                                </p>
                            </td>
                            
                        </tr>
                         <tr class="route-row532">
                            <td>2</td>
                            <td>Ga Hà Nội</td>
                            <td>Ga Đà Nẵng</td>
                            <td>Tàu A06</td>
                            <td style="text-align: center;">2019-05-29</td>
                            <td style="text-align: center;">2019-05-30</td>
                            <td style="text-align: center;">10:00 AM</td>
                            <td style="text-align: center;">
                                <p>
                                    <strong class="text-primary">
                                        550.000<sup>đ/vé</sup>
                                    </strong>
                                </p>
                            </td>
                            
                        </tr>
                         <tr class="route-row532">
                            <td>2</td>
                            <td>Ga Hà Nội</td>
                            <td>Ga Nghệ An</td>
                            <td>Tàu A07</td>
                            <td style="text-align: center;">2019-05-29</td>
                            <td style="text-align: center;">2019-05-30</td>
                            <td style="text-align: center;">14:30 PM</td>
                            <td style="text-align: center;">
                                <p>
                                    <strong class="text-primary">
                                        450.000<sup>đ/vé</sup>
                                    </strong>
                                </p>
                            </td>
                            
                        </tr>
                                        </tbody> 
                </table>    
            </div>      
        </div>
                <div class="section-list" id="Star-nghe-an">
            <h3 class="text-uppercase text-success">
                <span class="sprite ico-drive"></span>Hà Nội <i class="fa fa-exchange"> Miền Bắc</i>
            </h3>    
            <div class="table-responsive">
                <table class="table ">
                    <thead>
                        <tr class="text-white bg-light-green">
                            <th>STT</th>
                            <th data-toggle="true">Ga đi</th>
                            <th>Ga đến</th>
                            <th data-hide="phone">Tên tàu</th>
                            <th data-hide="phone" style="text-align: center;">Ngày Đi</th>
                            <th data-hide="phone" style="text-align: center;">Ngày Về</th>
                            <th data-hide="phone" style="text-align: center;">Giờ Xuất Phát</th>
                            <th data-hide="phone" style="text-align: center;">Giá vé</th>
                            <th></th>
                        </tr>
                    </thead> 
                    <tbody>
                          <tr class="route-row532">
                            <td>1</td>
                            <td>Ga Hà Nội</td>
                            <td>Ga Hải Dương</td>
                            <td>Tàu A03</td>
                            <td style="text-align: center;">2019-05-28</td>
                            <td style="text-align: center;">2019-05-29</td>
                            <td style="text-align: center;">8:00 AM</td>
                            <td style="text-align: center;">
                                <p>
                                    <strong class="text-primary">
                                        200.000<sup>đ/vé</sup>
                                    </strong>
                                </p>
                            </td>
                            
                        </tr>
                                            <tr class="route-row532">
                            <td>2</td>
                            <td>Ga Hà Nội</td>
                            <td>Ga Lạng Sơn</td>
                            <td>Tàu A07</td>
                            <td style="text-align: center;">2019-06-01</td>
                            <td style="text-align: center;">2019-06-02</td>
                            <td style="text-align: center;">9:00 AM</td>
                            <td style="text-align: center;">
                                <p>
                                    <strong class="text-primary">
                                        285.000<sup>đ/vé</sup>
                                    </strong>
                                </p>
                            </td>
                           
                        </tr>
                        <tr class="route-row532">
                            <td>1</td>
                            <td>Ga Hà Nội</td>
                            <td>Ga Thanh Hóa</td>
                            <td>Tàu A04</td>
                            <td style="text-align: center;">2019-05-28</td>
                            <td style="text-align: center;">2019-05-29</td>
                            <td style="text-align: center;">11:00 AM</td>
                            <td style="text-align: center;">
                                <p>
                                    <strong class="text-primary">
                                        300.000<sup>đ/vé</sup>
                                    </strong>
                                </p>
                            </td>
                            
                        </tr>

                        <tr class="route-row532">
                            <td>1</td>
                            <td>Ga Hà Nội</td>
                            <td>Ga Phủ Lý</td>
                            <td>Tàu A05</td>
                            <td style="text-align: center;">2019-05-28</td>
                            <td style="text-align: center;">2019-05-29</td>
                            <td style="text-align: center;">13:00 PM</td>
                            <td style="text-align: center;">
                                <p>
                                    <strong class="text-primary">
                                        200.000<sup>đ/vé</sup>
                                    </strong>
                                </p>
                            </td>
                            
                        </tr>
                                        </tbody> 
                </table>    
            </div>      
        </div>
            </div><!-- end #main-wrap -->

</section><!-- END content-container -->

