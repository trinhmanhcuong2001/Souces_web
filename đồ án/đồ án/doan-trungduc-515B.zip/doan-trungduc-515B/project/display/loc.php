<div id="price_filter-3" class="widget"><h3>Lọc theo khoảng giá</h3>
            <form method="get" action="index.php?page=sanpham.php">
              <div class="price_slider_wrapper">
				
				<div class="price_slider_amount">
					<input type="text"  name="min" value="" placeholder="Nhỏ nhất" />
					<input type="text" name="max" value=""  placeholder="Lớn nhất" />
					<button type="submit" class="button">Lọc</button>
					<div class="clear"></div>
				</div>
		</div>                      
            </form>
                                        
                                </div>